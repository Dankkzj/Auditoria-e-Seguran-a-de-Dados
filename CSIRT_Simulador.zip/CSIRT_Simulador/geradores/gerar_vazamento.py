import random
import time
from datetime import datetime

#Configuração
ips_internos = ['192.168.1.102', '192.168.1.115', '192.168.1.120']
ip_vazador = '192.168.1.115'

arquivos_sensiveis = [
    '/share/financeiro/planilha_salarios_2025.xlsx',
    '/share/clientes/base_completa_clientes.csv',
    '/share/dev/codigo_fonte_app_principal.zip'
]

ips_externos_maliciosos = ['104.22.33.44', '172.67.1.5']

caminho_do_log = "ambiente_simulador/var/logs/simulador/firewall_dlp.log"

print(f"[*] Gerador de Vazamento de Dados INICIADO.")
print(f"[*] Escrevendo logs em: {caminho_do_log}")


while True: 
    try:
    
        agora = datetime.now()
        data_formatada = agora.strftime("%b %d %H:%M:%S")

        arquivo = random.choice(arquivos_sensiveis)
        ip_destino = random.choice(ips_externos_maliciosos)
        
        ip_interno_aleatorio = random.choice(ips_internos)
        log_acesso_normal = f"{data_formatada} file_server smbd[991]: {ip_interno_aleatorio} acessou /share/documentos/template.docx"

        log_acesso_suspeito = f"{data_formatada} file_server smbd[992]: {ip_vazador} acessou {arquivo}"
        
        tamanho_dados_mb = random.randint(20, 150)
        log_exfiltracao_dlp = f"{data_formatada} firewall_dlp panos[111]: ALERTA_DLP Conexão de {ip_vazador} para {ip_destino} (Transferência de {tamanho_dados_mb}MB detectada) REGRA: 'Bloquear Exfiltração de Dados'"

        
        with open(caminho_do_log, "a", encoding="utf-8") as f:
            f.write(log_acesso_normal + "\n")
            
            time.sleep(random.randint(1, 3))
            f.write(log_acesso_suspeito + "\n")
            time.sleep(1)
            f.write(log_exfiltracao_dlp + "\n")
            
        
        tempo_pausa = random.uniform(10, 30)
        time.sleep(tempo_pausa)

    except FileNotFoundError:
        print(f"ERRO CRÍTICO: Pasta ou caminho não encontrado:")
        print(f"{caminho_do_log}")
        print("Crie a estrutura de pastas '/ambiente_simulado/var/logs/simulador/'")
        break
        
    except Exception as e:
        print(f"ERRO INESPERADO: {e}")
        time.sleep(5)