import random
import time
from datetime import datetime

#Configuração
ips_ataque = ['55.123.9.8', '101.99.88.7', '33.44.55.6', '102.2.3.4']
payloads_sqli = [
    "' OR '1'='1",
    "admin'--",
    "1' UNION SELECT 1,2,3--",
    "' OR 1=1 LIMIT 1; --",
    "1 AND 1=1",
    "admin' OR 1=1 /*"
]

caminho_do_log = "ambiente_simulador/var/logs/simulador/web_app.log"

print(f"[*] Gerador de Injeção SQL (SQLi) INICIADO.")
print(f"[*] Escrevendo logs em: {caminho_do_log}")


while True: 
    try:

        
        agora = datetime.now()
        data_formatada = agora.strftime("%b %d %H:%M:%S")

    
        ip_aleatorio = random.choice(ips_ataque)
        ataque_aleatorio = random.choice(payloads_sqli)
        
        linha_de_log = f'{data_formatada} 192.168.1.10 (servidor) GET /login.php?user={ataque_aleatorio}&pass=pass HTTP/1.1 400 - "Agente Falso" {ip_aleatorio}'

        with open(caminho_do_log, "a", encoding="utf-8") as f:
            f.write(linha_de_log + "\n")
            
        tempo_pausa = random.uniform(1, 4)
        time.sleep(tempo_pausa)

    except FileNotFoundError:
        print(f"ERRO CRÍTICO: Pasta ou caminho não encontrado:")
        print(f"{caminho_do_log}")
        print("Por favor, crie a estrutura de pastas '/ambiente_simulado/var/logs/simulador/' e rode novamente.")
        break
        
    except Exception as e:
        print(f"ERRO INESPERADO: {e}")
        time.sleep(5)