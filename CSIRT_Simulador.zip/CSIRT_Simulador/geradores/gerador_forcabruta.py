import random
import time
from datetime import datetime

#Configuração
ips_ataques = ['102.2.3.4', '199.22.88.1','50.60.70.80','123.45.67.89']
usuarios_alvos = ['root', 'admin', 'user', 'guest', 'adm', 'suporte']

caminho_do_log = "ambiente_simulador/var/logs/simulador/auth.log"

print(f"[*] Gerador de Força Bruta (SSH) INICIADO.")
print(f"[*] Escrevendo logs em: {caminho_do_log}")

#Loop da Simulação 
while True: 
    try:
        agora = datetime.now()
        data_formatada = agora.strftime("%b %d %H:%M:%S")

        ip_aleatorio = random.choice(ips_ataques)
        usuarios_aleatorios = random.choice(usuarios_alvos)
        
        # ERRO 5 CORRIGIDO: "sshd"
        linha_de_log = f"{data_formatada} servidor_conphia sshd[1234]: Failed password for invalid user {usuarios_aleatorios} from {ip_aleatorio} port 22"

        # ERRO 2 CORRIGIDO: "utf-8"
        with open(caminho_do_log, "a", encoding="utf-8") as f: 
            f.write(linha_de_log + "\n") 

    except FileNotFoundError:
        # Um erro específico se a pasta não existir
        print(f"ERRO CRÍTICO: Pasta ou caminho não encontrado:")
        print(f"{caminho_do_log}")
        print("Por favor, crie a estrutura de pastas e rode novamente.")
        break # Para o script se a pasta não existe

    except Exception as e:
        print(f"ERRO AO SALVAR O LOG:{e}")

    # ERRO 4 CORRIGIDO: Removi os prints de debug que estavam aqui.

    time.sleep(1)