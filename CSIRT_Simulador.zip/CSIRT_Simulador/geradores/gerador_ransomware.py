import random
import time
from datetime import datetime
import os # <<< MUDANÇA AQUI: Vamos interagir com o sistema de arquivos

# --- 1. Configuração ---
# A pasta que o ransomware vai "atacar"
# IMPORTANTE: Só vai mexer dentro desta pasta
pasta_alvo = "ambiente_simulador/documento_empresa/"

# A extensão que o ransomware vai adicionar
extensao_ransomware = ".ENCRYPTED_CSIRT"

# O nome da nota de resgate
nome_nota_resgate = "LEIA_PARA_TER_SEUS_ARQUIVOS.txt"

# Conteúdo da nota de resgate
conteudo_nota = f"""
SEUS ARQUIVOS FORAM "CRIPTOGRAFADOS"! (Isto é uma simulação)

Todos os seus documentos, relatórios e dados de clientes agora têm a extensão {extensao_ransomware}.
Para recuperá-los, você (o estudante) deve detectar este incidente, 
analisar os logs e propor uma solução.

- Vetor de Ataque: Simulado (Processo 'ransom.exe')
- Ação: Renomeação de arquivos.
- Próximo Passo: Analise o log 'file_system.log' para encontrar o PID do processo.

- Seu CSIRT
"""

# --- 2. Configuração do Log ---
# O ransomware também deixa logs (no log do sistema de arquivos)
caminho_do_log = "ambiente_simulado/var/logs/simulador/file_system.log"

# --- 3. Mensagem de Início ---
print(f"[*] Gerador de Ransomware INICIADO.")
print(f"[*] Pasta Alvo: {pasta_alvo}")
print(f"[*] Log de Eventos: {caminho_do_log}")

# --- 4. A Simulação (Roda UMA VEZ e para) ---
# Diferente dos outros, o ransomware ataca de uma vez.
# Não vamos usar um 'while True:', ele vai rodar, atacar e sair.

try:
    # --- A. Verificar se a pasta alvo existe ---
    if not os.path.isdir(pasta_alvo):
        print(f"ERRO: A pasta alvo '{pasta_alvo}' não existe.")
        print("Por favor, crie-a e adicione arquivos falsos dentro dela.")
    else:
        print(f"\n[+] Iniciando ataque na pasta: {pasta_alvo}")
        
        # Gerar um ID de processo (PID) falso para o log
        pid_falso = random.randint(1000, 9999)
        agora = datetime.now().strftime("%b %d %H:%M:%S")

        # --- B. "Criptografar" (Renomear) os arquivos ---
        arquivos_afetados = []
        for nome_arquivo in os.listdir(pasta_alvo):
            
            caminho_completo_original = os.path.join(pasta_alvo, nome_arquivo)
            
            # Só mexe em arquivos, e ignora a si mesmo (a nota de resgate)
            if os.path.isfile(caminho_completo_original) and nome_arquivo != nome_nota_resgate:
                
                novo_nome = nome_arquivo + extensao_ransomware
                caminho_completo_novo = os.path.join(pasta_alvo, novo_nome)
                
                # A "CRIPTOGRAFIA" é só um RENAME
                os.rename(caminho_completo_original, caminho_completo_novo)
                
                print(f"  -> 'Criptografado': {nome_arquivo} -> {novo_nome}")
                arquivos_afetados.append(nome_arquivo)
                time.sleep(0.5) # Simula o tempo de criptografia
        
        # --- C. Deixar a Nota de Resgate ---
        if arquivos_afetados: # Só deixa a nota se tiver "criptografado" algo
            caminho_nota = os.path.join(pasta_alvo, nome_nota_resgate)
            with open(caminho_nota, "w", encoding="utf-8") as f:
                f.write(conteudo_nota)
            print(f"[+] Nota de resgate deixada em: {caminho_nota}")

        # --- D. Salvar o Log do Evento ---
        with open(caminho_do_log, "a", encoding="utf-8") as f:
            for arquivo in arquivos_afetados:
                log_evento = f"{agora} system_monitor kernel: Processo 'ransom.exe' (PID: {pid_falso}) modificou o arquivo '{os.path.join(pasta_alvo, arquivo)}'"
                f.write(log_evento + "\n")
            log_summary = f"{agora} system_monitor kernel: Processo 'ransom.exe' (PID: {pid_falso}) encerrou. {len(arquivos_afetados)} arquivos modificados."
            f.write(log_summary + "\n")
            
        print(f"[+] Logs do ataque escritos em: {caminho_do_log}")
        print("\n[!] ATAQUE DE RANSOMWARE SIMULADO CONCLUÍDO [!]")

except Exception as e:
    print(f"ERRO INESPERADO DURANTE O ATAQUE: {e}")