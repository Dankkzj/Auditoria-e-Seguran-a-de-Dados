import random
import time
from datetime import datetime

#Configuração 
usuarios_internos = [
    'joao.silva@conphia.com', 
    'maria.santos@conphia.com', 
    'ana.oliveira@conphia.com', 
    'pedro.costa@conphia.com'
]

remetentes_falsos = [
    'premio@promocaornicrosoft.com', 
    'suporte@rnicrosof.com', 
    'rh@corphia-dados.com'
]

links_maliciosos = [
    'http://clique-aqui-premio.xyz/login', 
    'http://bit.ly/atualizar-banco', 
    'http://185.12.3.99/rh-portal'
]

caminho_do_log = "ambiente_simulador/var/logs/simulador/mail.log"

print(f"[*] Gerador de Phishing INICIADO.")
print(f"[*] Escrevendo logs em: {caminho_do_log}")

while True: 
    try:
        # --- A. Coletar Dados para o Log ---
        agora = datetime.now()
        data_formatada = agora.strftime("%b %d %H:%M:%S")

        usuario = random.choice(usuarios_internos)
        remetente = random.choice(remetentes_falsos)
        link = random.choice(links_maliciosos)
        
        #Checo aqui tem duas linhas de log que é pra saber que foi enviada e outra para saber se foi clicada
        
        #recebido do email
        log_entrega = f"{data_formatada} mail_server postfix/smtp[1234]: message-id=123ABC_EMAIL: to=<{usuario}>, from=<{remetente}>, status=sent"
        
        #simulado por um log de firewall
        log_clique = f"{data_formatada} proxy_firewall squid[5678]: {usuario} TCP_MISS/200 GET {link} - DIRECT/185.12.3.99"

        
        # --- C. Salvar o Log no Arquivo ---
        with open(caminho_do_log, "a", encoding="utf-8") as f:
            f.write(log_entrega + "\n")
            
            #aqui eu coloquei pra aleatorizar os cliques 
            if random.random() > 0.3:            
                time.sleep(random.randint(1, 5)) 
                f.write(log_clique + "\n")
            
        tempo_pausa = random.uniform(5, 15) 
        time.sleep(tempo_pausa)

    except FileNotFoundError:
        print(f"ERRO CRÍTICO: Pasta ou caminho não encontrado:")
        print(f"{caminho_do_log}")
        print("Crie a estrutura de pastas '/ambiente_simulado/var/logs/simulador/'")
        break
        
    except Exception as e:
        print(f"ERRO INESPERADO: {e}")
        time.sleep(5)